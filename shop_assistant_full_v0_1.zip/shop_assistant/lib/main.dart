import 'package:flutter/material.dart';

void main() => runApp(const ShopAssistantApp());

class Device {
  String name;
  String brand;
  String model;
  String height;
  String width;
  String thickness;
  String screen;
  String notes;

  Device({
    required this.name,
    required this.brand,
    required this.model,
    this.height = '',
    this.width = '',
    this.thickness = '',
    this.screen = '',
    this.notes = '',
  });
}

class ShopAssistantApp extends StatelessWidget {
  const ShopAssistantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مساعد المتجر',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF06101E),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF247BFF),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

final List<Device> devices = [
  Device(name: 'Galaxy A55', brand: 'Samsung', model: 'SM-A556', height: '161.1', width: '77.4', thickness: '8.2', screen: '6.6'),
  Device(name: 'Redmi 9C', brand: 'Xiaomi', model: 'M2006C3MG', height: '164.9', width: '77.1', thickness: '9.0', screen: '6.53'),
  Device(name: 'Note 40 Pro', brand: 'Infinix', model: 'X6851', height: '164.3', width: '74.6', thickness: '8.1', screen: '6.78'),
  Device(name: 'A96', brand: 'Oppo', model: 'CPH2333', height: '164.4', width: '75.7', thickness: '8.4', screen: '6.59'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  String query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = devices.where((d) {
      final q = query.trim().toLowerCase();
      return q.isEmpty || '${d.brand} ${d.name} ${d.model}'.toLowerCase().contains(q);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('مساعد المتجر', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: index == 0
          ? _dashboard(context)
          : index == 1
              ? _devices(context, filtered)
              : _placeholder(index),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.phone_android_outlined), selectedIcon: Icon(Icons.phone_android), label: 'الأجهزة'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'الكفرات'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'اللّزكات'),
        ],
      ),
    );
  }

  Widget _dashboard(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      _searchBox(),
      const SizedBox(height: 18),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.45,
        children: [
          _tile('الأجهزة', 'مواصفات وأبعاد الأجهزة', Icons.phone_android, Colors.blue, () => setState(() => index = 1)),
          _tile('الكفرات', 'التوافق مع الأجهزة', Icons.phone_iphone, Colors.deepPurple, () => setState(() => index = 2)),
          _tile('لزقات الشاشة', 'الأبعاد والتوافق', Icons.shield, Colors.green, () => setState(() => index = 3)),
          _tile('المطابقة الذكية', 'ابحث بالأبعاد', Icons.search, Colors.orange, () {}),
        ],
      ),
      const SizedBox(height: 24),
      const Text('أحدث الأجهزة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...devices.take(3).map(_deviceCard),
    ]);
  }

  Widget _devices(BuildContext context, List<Device> filtered) {
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 8), child: _searchBox()),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(children: [
          const Text('قائمة الأجهزة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Spacer(),
          FilledButton.icon(onPressed: () => _addDevice(context), icon: const Icon(Icons.add), label: const Text('إضافة')),
        ]),
      ),
      Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: filtered.length, itemBuilder: (_, i) => _deviceCard(filtered[i]))),
    ]);
  }

  Widget _searchBox() => TextField(
        onChanged: (v) => setState(() => query = v),
        decoration: InputDecoration(
          hintText: 'ابحث عن جهاز، موديل أو شركة...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          fillColor: const Color(0xFF122238),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      );

  Widget _tile(String title, String sub, IconData icon, Color color, VoidCallback onTap) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 32), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 3), Text(sub, style: TextStyle(color: Colors.grey.shade400, fontSize: 11)),
        ]))),
      );

  Widget _deviceCard(Device d) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          leading: CircleAvatar(backgroundColor: const Color(0xFF1D63D8), child: const Icon(Icons.phone_android)),
          title: Text('${d.brand} ${d.name}', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${d.screen}"  •  ${d.height} × ${d.width} × ${d.thickness} mm'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => _details(d),
        ),
      );

  void _details(Device d) => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: const Color(0xFF0A1728),
        builder: (_) => Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 35), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(4)))),
          const SizedBox(height: 20), Text('${d.brand} ${d.name}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          Text(d.model, style: TextStyle(color: Colors.grey.shade400)), const SizedBox(height: 20),
          _row('الطول', '${d.height} mm'), _row('العرض', '${d.width} mm'), _row('السماكة', '${d.thickness} mm'), _row('حجم الشاشة', '${d.screen}"'),
          const SizedBox(height: 16), SizedBox(width: double.infinity, child: FilledButton(onPressed: () {}, child: const Text('عرض الكفرات واللزقات المناسبة'))),
        ])),
      );

  Widget _row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Text(a), const Spacer(), Text(b, style: const TextStyle(fontWeight: FontWeight.bold))]));

  void _addDevice(BuildContext context) {
    final name = TextEditingController(), brand = TextEditingController(), model = TextEditingController(), h = TextEditingController(), w = TextEditingController(), t = TextEditingController(), s = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('إضافة جهاز'),
      content: SingleChildScrollView(child: Column(children: [
        _field(name, 'اسم الجهاز'), _field(brand, 'الشركة'), _field(model, 'رقم الموديل'),
        _field(h, 'الطول mm'), _field(w, 'العرض mm'), _field(t, 'السماكة mm'), _field(s, 'حجم الشاشة'),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: () { if (name.text.trim().isEmpty) return; setState(() => devices.add(Device(name: name.text, brand: brand.text, model: model.text, height: h.text, width: w.text, thickness: t.text, screen: s.text))); Navigator.pop(context); }, child: const Text('حفظ'))],
    ));
  }

  Widget _field(TextEditingController c, String label) => Padding(padding: const EdgeInsets.only(bottom: 9), child: TextField(controller: c, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())));

  Widget _placeholder(int i) => Center(child: Text(i == 2 ? 'قسم الكفرات — راح نضيفه بالمرحلة التالية' : 'قسم اللزكات — راح نضيفه بالمرحلة التالية', style: const TextStyle(fontSize: 17)));
}
