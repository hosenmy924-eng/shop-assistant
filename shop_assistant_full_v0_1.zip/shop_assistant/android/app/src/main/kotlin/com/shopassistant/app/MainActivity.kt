package com.shopassistant.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
